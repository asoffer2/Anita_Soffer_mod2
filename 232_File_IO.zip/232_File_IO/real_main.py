def read_lines(filename):
    """Read the each line in a file and return in a list with stripped newlines"""
    stripped_lines = []
    with open(filename) as f:
        for line in f:
            line = line.strip("\n")
            stripped_lines.append(line) # add each stripped line to a list
    return stripped_lines


def normalize_line(line: str):
    """Format and return a normalized line, where each field meets its specifications"""
    # first get rid of spaces and multiple lines
    split_line = line.split("|")
    cleaned_list = []
    for i,item in enumerate(split_line):
        new_item = item.strip()
        if new_item == "" or new_item == "|":
            continue # not adding extra spaces or lines
        else:
            cleaned_list.append(new_item)

    normalized = []
    for item in cleaned_list:
        field = item.lower() # to make input case-insensitive
        if field.startswith("grade"): # pulling out the "grade" field
            _, value = field.split("=") # separate field title from value to strip middle spaces
            value = value.strip()
            grade = "grade=" + value # normalized grade field
            normalized.append(grade)
            continue # done with the loop if this was satisfied, so continue
        if field.startswith("prof"): # pulling professor field
            _, value = field.split(":") # same method as grade, splits on :
            # normalize the professor field
            value = value.title()
            value = value.strip()
            prof = "prof:" + value
            normalized.append(prof)
            continue
        normalized.append(item)
    normalized = "|".join(normalized) # join line back together with one line as a separator
    return normalized


def parse_record(clean_line:str):
    """Coverts the normalized line into a tuple with required information, returns None if does not meet the criteria"""
    # get each field as an item in a list
    line_list = clean_line.split("|")
    # since it has been normalized, the third value must be the professor field. Return None if not.
    if not line_list[2].startswith("prof"):
        return None
    # same method for the grade field
    if not line_list[3].startswith("grade="):
        return None
    # if there are too many fields, returns None
    if len(line_list) < 4:
        return None

    # accessing the professor's last name from the normalized field
    _, name = line_list[2].split(":")
    professor_last_name = name

    # accessing the grade to check if it can be converted to an integer
    _, grade = line_list[3].split("=")

    # catch an error and return None of age or grade cannot be converted to an int
    try:
        age = int(line_list[1])
        if age < 15 or age > 99:
            return None
        grade = int(grade)
        if grade < 0 or grade > 100:
            return None
    except ValueError:
        return None

    # accept the student's name as the first field of a normalized line
    student_full_name = line_list[0]
    # pull it all together into a tuple of the required information
    record_tuple = (student_full_name, age, professor_last_name, grade)
    return record_tuple


def write_clean_records(records, filename):
    """Write the cleaned records to a new file, formatted."""
    with open(filename, "w") as f:
        for record in records:
            student_full_name, age, professor_last_name, grade = record # unpack each tuple
            f.write(f"{student_full_name}|{age}|{professor_last_name}|{grade}\n") # write with formatting


def write_invalid_lines(bad_lines, filename):
    """Writes the invalid records to a new file"""
    with open(filename, "w") as f:
        for bad_line in bad_lines:
            f.write(f"{bad_line}\n")


def average_grade(records):
    """Returns the class average based on the records."""
    # isolate a list of grades
    grades = [grade for student_full_name, age, professor_last_name, grade in records]
    my_sum = 0
    count = 0
    for grade in grades:
        count += 1 # add one to the count for every grade
        my_sum += grade # add each grade to the sum
    average = my_sum / count # calculate average
    return average


def professor_summary(records):
    """Calculate and return a list of tuples with each professor's last name, number
    of students, and grade point average."""
    # initialize list
    summary_list = []

    # isolate the professors into a list
    professors = [professor_last_name for student_full_name, age, professor_last_name, grade in records ]
    # get rid of duplicates
    unique_professors = []
    for p in professors:
        if p not in unique_professors:
            unique_professors.append(p)
    for professor in unique_professors: # run a loop of each professor
        # initialize each professor's count and grade_sum at 0
        count = 0
        grade_sum = 0
        # go through each record
        for record in records:
            student_full_name, age, professor_last_name, grade = record # unpack each record
            # if the tuple information is about the current professor
            if professor_last_name == professor:
                # add the grade to the sum, and one to the count to calculate average
                grade_sum += grade
                count += 1
        grade_avg = grade_sum / count # calculate grade average
        summary = (professor, count, grade_avg) # create summary tuple for the professor
        summary_list.append(summary) # append the professor's tuple to the list
    return summary_list


def top_student_per_prof(records):
    """Calculate and return a list of tuples with each professor's last name, student name, and grade."""
    # get a list of professors with duplicates removed
    professors = [professor_last_name for student_full_name, age, professor_last_name, grade in records]
    unique_professors = []
    best_list = []
    for p in professors:
        if p not in unique_professors:
            unique_professors.append(p)
    for professor in unique_professors: # a loop for each professor
        # initialize best name and grade as None
        best_name = None
        best_grade = None
        for record in records:
            student_full_name, age, professor_last_name, grade = record # unpack each tuple in records
            if professor_last_name == professor:
                if best_grade is None or grade > best_grade: # if the grade is the highest, reset the variables
                    best_grade = grade
                    best_name = student_full_name
        best_tuple = (professor, best_name, best_grade)
        best_list.append(best_tuple)
    return best_list


def write_report(records, bad_lines, filename):
    """Write a full report to a new file formatted, using the top student and professor summary functions."""
    # calculate how many valid and invalid lines
    valid_line_count = 0
    bad_line_count = 0
    for _ in records:
        valid_line_count += 1
    for _ in bad_lines:
        bad_line_count += 1

    # get a list of grades to calculate the average
    grades = [grade for student_full_name, age, professor_last_name, grade in records]
    grade_sum = 0
    grade_count = 0
    for grade in grades:
        grade_count += 1
        grade_sum += grade
    class_average = grade_sum/grade_count
    summary_list = professor_summary(records)
    best_list = top_student_per_prof(records)

    # write a file with all the information formatted
    with open(filename, "w") as f:
        f.write(f"VALID RECORDS: {valid_line_count}, INVALID RECORDS: {bad_line_count}, CLASS AVERAGE: {class_average:.2f}\n")
        f.write("\n")
        f.write("PROFESSOR SUMMARY:\n")
        for professor, students, grade_avg in summary_list:
            f.write(f"{professor} | students: {students} | avg: {grade_avg:.2f}\n")
        f.write("\n")
        f.write("TOP STUDENT PER PROFESSOR:\n")
        for prof, best_student, best_grade in best_list:
            f.write(f"{prof} | {best_student} | {best_grade}\n")


def main():
    """Pulling all functions together using the starter test harness provided"""
    raw = read_lines("raw_records.txt")

    valid_records = []
    invalid_lines = []

    for line in raw:
        clean = normalize_line(line)
        rec = parse_record(clean)
        if rec is None:
            invalid_lines.append(line)
        else:
            valid_records.append(rec)

    write_clean_records(valid_records, "clean_records.txt")
    write_invalid_lines(invalid_lines, "invalid_records.txt")
    write_report(valid_records, invalid_lines,"report.txt")

    print("Done. Wrote clean_records.txt, invalid_records.txt, report.txt")


if __name__ == "__main__":
    main()